# TPS Quinto anno JAVA Socket TCP
Questo è un semplice repository basato su **JAVA SOCKET**.

## Tecnologie:
- **JAVA**

## Contenuti:
- **Applicazioni con Socket TCP in JAVA**

## Come scaricare i contenuti:

1. Clona il repository:

git clone https://github.com/MarioGiagnotti/TPS-Quinto-anno-JAVA-Socket-TCP.git

2. Come testare i contenuti
     - Aprire la cartella in Visual Studio Code
     - Per ogni applicazione far partire prima il server e poi i client
     - Verificare nei terminali l'applicazione

