# Simulazione delle estrazioni del Lotto con PHP

## Obiettivo dell'esercitazione

Realizzare una pagina PHP che genera e visualizza una tabella simile a
quella delle estrazioni del Lotto.

La tabella avrà:

-   una prima colonna con il nome della ruota;
-   cinque colonne successive con i numeri estratti;
-   una riga per ciascuna ruota.

L'esercitazione propone tre soluzioni progressive:

1.  **Versione 1 -- senza cicli:** utilizza array, `rand()` e codice
    HTML/PHP ripetuto manualmente.
2.  **Versione 2 -- con cicli, senza controllo dei duplicati:** utilizza
    array e cicli `foreach` e `for`; uno stesso numero può comparire più
    volte sulla stessa ruota.
3.  **Versione 3 -- soluzione più efficiente:** utilizza array e cicli e
    controlla che i cinque numeri di ogni ruota siano diversi tra loro.

> **Nota didattica:** in questa simulazione ogni ruota estrae cinque
> numeri compresi tra 1 e 90. Il controllo dei duplicati viene applicato
> separatamente a ciascuna ruota: un numero uscito su Bari, per esempio,
> può uscire anche su Cagliari. Questo comportamento è coerente con il
> modo in cui si svolge un'estrazione indipendente per ogni ruota.

------------------------------------------------------------------------

# 1. Preparazione dell'ambiente

Per eseguire gli esempi è necessario un ambiente con PHP, ad esempio
XAMPP.

1.  Avviare Apache dal pannello di controllo di XAMPP.
2.  Creare una cartella, ad esempio `lotto`, all'interno di
    `C:\xampp\htdocs`.
3.  Creare al suo interno un file chiamato `index.php`.
4.  Inserire nel file il codice di una delle versioni proposte.
5.  Aprire il browser e digitare:

``` text
http://localhost/lotto/
```

Non è sufficiente aprire il file facendo doppio clic: il codice PHP deve
essere interpretato dal server Apache.

## Dati utilizzati

Le ruote considerate sono le undici ruote del Lotto:

``` php
$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];
```

Per ogni ruota vengono generati cinque numeri, da 1 a 90 inclusi.

------------------------------------------------------------------------

# 2. Versione 1 -- Soluzione senza cicli

## 2.1 Idea della soluzione

In questa prima versione non utilizziamo alcun ciclo (`for`, `foreach` o
`while`).

La soluzione procede in modo esplicito:

1.  definiamo l'array contenente i nomi delle ruote;
2.  generiamo cinque numeri casuali per ciascuna ruota, usando
    `rand(1, 90)`;
3.  inseriamo i risultati in un array;
4.  stampiamo manualmente le righe della tabella.

Questa versione è volutamente ripetitiva. Serve a comprendere come si
generano numeri casuali, come si memorizzano in un array e come PHP può
produrre codice HTML.

**Attenzione:** in questa prima versione non viene verificata l'unicità
dei numeri. Perciò, sulla stessa ruota, potrebbero comparire ad esempio
due numeri 24.

## 2.2 Codice completo -- `index.php`

``` php
<?php
// Elenco delle ruote
$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];

// Generazione manuale dei cinque numeri per ogni ruota.
// Ogni chiamata a rand(1, 90) restituisce un numero tra 1 e 90.

$bari = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$cagliari = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$firenze = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$genova = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$milano = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$napoli = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$palermo = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$roma = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$torino = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$venezia = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$nazionale = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulazione estrazioni Lotto - Versione 1</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f4f6f8;
        }

        h1 {
            text-align: center;
            color: #17365d;
        }

        table {
            width: 100%;
            max-width: 850px;
            margin: 25px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #b8c4ce;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #17365d;
            color: white;
        }

        td:first-child {
            font-weight: bold;
            background-color: #e8eef5;
        }

        .numero {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<h1>Simulazione estrazioni del Lotto</h1>

<table>
    <tr>
        <th>Ruota</th>
        <th>1° numero</th>
        <th>2° numero</th>
        <th>3° numero</th>
        <th>4° numero</th>
        <th>5° numero</th>
    </tr>

    <tr>
        <td><?php echo $ruote[0]; ?></td>
        <td class="numero"><?php echo $bari[0]; ?></td>
        <td class="numero"><?php echo $bari[1]; ?></td>
        <td class="numero"><?php echo $bari[2]; ?></td>
        <td class="numero"><?php echo $bari[3]; ?></td>
        <td class="numero"><?php echo $bari[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[1]; ?></td>
        <td class="numero"><?php echo $cagliari[0]; ?></td>
        <td class="numero"><?php echo $cagliari[1]; ?></td>
        <td class="numero"><?php echo $cagliari[2]; ?></td>
        <td class="numero"><?php echo $cagliari[3]; ?></td>
        <td class="numero"><?php echo $cagliari[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[2]; ?></td>
        <td class="numero"><?php echo $firenze[0]; ?></td>
        <td class="numero"><?php echo $firenze[1]; ?></td>
        <td class="numero"><?php echo $firenze[2]; ?></td>
        <td class="numero"><?php echo $firenze[3]; ?></td>
        <td class="numero"><?php echo $firenze[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[3]; ?></td>
        <td class="numero"><?php echo $genova[0]; ?></td>
        <td class="numero"><?php echo $genova[1]; ?></td>
        <td class="numero"><?php echo $genova[2]; ?></td>
        <td class="numero"><?php echo $genova[3]; ?></td>
        <td class="numero"><?php echo $genova[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[4]; ?></td>
        <td class="numero"><?php echo $milano[0]; ?></td>
        <td class="numero"><?php echo $milano[1]; ?></td>
        <td class="numero"><?php echo $milano[2]; ?></td>
        <td class="numero"><?php echo $milano[3]; ?></td>
        <td class="numero"><?php echo $milano[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[5]; ?></td>
        <td class="numero"><?php echo $napoli[0]; ?></td>
        <td class="numero"><?php echo $napoli[1]; ?></td>
        <td class="numero"><?php echo $napoli[2]; ?></td>
        <td class="numero"><?php echo $napoli[3]; ?></td>
        <td class="numero"><?php echo $napoli[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[6]; ?></td>
        <td class="numero"><?php echo $palermo[0]; ?></td>
        <td class="numero"><?php echo $palermo[1]; ?></td>
        <td class="numero"><?php echo $palermo[2]; ?></td>
        <td class="numero"><?php echo $palermo[3]; ?></td>
        <td class="numero"><?php echo $palermo[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[7]; ?></td>
        <td class="numero"><?php echo $roma[0]; ?></td>
        <td class="numero"><?php echo $roma[1]; ?></td>
        <td class="numero"><?php echo $roma[2]; ?></td>
        <td class="numero"><?php echo $roma[3]; ?></td>
        <td class="numero"><?php echo $roma[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[8]; ?></td>
        <td class="numero"><?php echo $torino[0]; ?></td>
        <td class="numero"><?php echo $torino[1]; ?></td>
        <td class="numero"><?php echo $torino[2]; ?></td>
        <td class="numero"><?php echo $torino[3]; ?></td>
        <td class="numero"><?php echo $torino[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[9]; ?></td>
        <td class="numero"><?php echo $venezia[0]; ?></td>
        <td class="numero"><?php echo $venezia[1]; ?></td>
        <td class="numero"><?php echo $venezia[2]; ?></td>
        <td class="numero"><?php echo $venezia[3]; ?></td>
        <td class="numero"><?php echo $venezia[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[10]; ?></td>
        <td class="numero"><?php echo $nazionale[0]; ?></td>
        <td class="numero"><?php echo $nazionale[1]; ?></td>
        <td class="numero"><?php echo $nazionale[2]; ?></td>
        <td class="numero"><?php echo $nazionale[3]; ?></td>
        <td class="numero"><?php echo $nazionale[4]; ?></td>
    </tr>
</table>

</body>
</html>
```

## 2.3 Spiegazione passo passo

### Passaggio 1 -- Definire l'array delle ruote

``` php
$ruote = ["Bari", "Cagliari", "Firenze", ...];
```

Un array è una struttura che consente di memorizzare più valori
all'interno di un'unica variabile.

Gli elementi sono identificati da un indice numerico che, in PHP, parte
da zero:

-   `$ruote[0]` contiene `Bari`;
-   `$ruote[1]` contiene `Cagliari`;
-   `$ruote[10]` contiene `Nazionale`.

### Passaggio 2 -- Generare i numeri casuali

``` php
$bari = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];
```

La funzione `rand(min, max)` restituisce un numero intero casuale
compreso tra il valore minimo e quello massimo, estremi inclusi.

In questo esempio:

-   `rand(1, 90)` genera un numero da 1 a 90;
-   la funzione viene richiamata cinque volte;
-   i cinque risultati vengono memorizzati nell'array `$bari`.

Ogni chiamata a `rand()` è indipendente dalle altre. Non essendoci un
controllo, due chiamate possono restituire lo stesso valore.

### Passaggio 3 -- Ripetere per tutte le ruote

Per ogni ruota viene creato un array distinto. La procedura è corretta,
ma poco scalabile: se si aggiungesse una nuova ruota, sarebbe necessario
scrivere altro codice manualmente.

### Passaggio 4 -- Stampare la tabella HTML

La struttura della tabella viene scritta direttamente in HTML.

``` php
<td><?php echo $ruote[0]; ?></td>
<td><?php echo $bari[0]; ?></td>
```

`echo` invia al browser il valore indicato. Il browser riceve quindi una
normale pagina HTML già generata dal server.

### Osservazioni didattiche

-   Non ci sono cicli.
-   Gli array permettono di conservare i cinque numeri di ogni ruota.
-   Il codice è semplice da seguire, ma contiene molte ripetizioni.
-   Non viene garantita l'unicità dei numeri estratti.

------------------------------------------------------------------------

# 3. Versione 2 -- Utilizzo dei cicli senza controllo dei duplicati

## 3.1 Idea della soluzione

In questa versione eliminiamo la maggior parte delle ripetizioni.

Utilizziamo:

-   un array per contenere i nomi delle ruote;
-   un array associativo per collegare ogni ruota ai propri numeri;
-   un ciclo `foreach` per scorrere le ruote;
-   un ciclo `for` per generare cinque numeri per ciascuna ruota;
-   un secondo ciclo `foreach` per stampare i risultati nella tabella.

Non introduciamo ancora il controllo dei duplicati. Di conseguenza, una
ruota potrebbe contenere due o più volte lo stesso numero.

## 3.2 Codice completo -- `index.php`

``` php
<?php

$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];

// Array che conterrà i risultati di tutte le ruote
$estrazioni = [];

// Scorro tutte le ruote
foreach ($ruote as $ruota) {

    // Creo un array vuoto per i numeri della ruota corrente
    $numeri = [];

    // Genero cinque numeri casuali
    for ($i = 0; $i < 5; $i++) {
        $numeri[] = rand(1, 90);
    }

    // Associo i cinque numeri al nome della ruota
    $estrazioni[$ruota] = $numeri;
}

?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulazione estrazioni Lotto - Versione 2</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f4f6f8;
        }

        h1 {
            text-align: center;
            color: #17365d;
        }

        table {
            width: 100%;
            max-width: 850px;
            margin: 25px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #b8c4ce;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #17365d;
            color: white;
        }

        td:first-child {
            font-weight: bold;
            background-color: #e8eef5;
        }

        .numero {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<h1>Simulazione estrazioni del Lotto</h1>

<table>
    <tr>
        <th>Ruota</th>
        <th>1° numero</th>
        <th>2° numero</th>
        <th>3° numero</th>
        <th>4° numero</th>
        <th>5° numero</th>
    </tr>

    <?php foreach ($estrazioni as $ruota => $numeri): ?>

        <tr>
            <td><?php echo $ruota; ?></td>

            <?php for ($i = 0; $i < 5; $i++): ?>
                <td class="numero">
                    <?php echo $numeri[$i]; ?>
                </td>
            <?php endfor; ?>

        </tr>

    <?php endforeach; ?>

</table>

</body>
</html>
```

## 3.3 Spiegazione passo passo

### Passaggio 1 -- Creare l'array delle ruote

``` php
$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];
```

L'array contiene tutti i nomi delle ruote. Non è necessario creare una
variabile diversa per ciascuna ruota.

### Passaggio 2 -- Preparare l'array dei risultati

``` php
$estrazioni = [];
```

Inizialmente l'array è vuoto. Durante l'esecuzione verrà popolato con
una struttura di questo tipo:

``` php
$estrazioni = [
    "Bari" => [12, 34, 45, 67, 89],
    "Cagliari" => [5, 18, 27, 44, 73],
    "Firenze" => [9, 21, 36, 58, 80]
];
```

I valori mostrati sono puramente esemplificativi: a ogni esecuzione
verranno generati nuovi numeri.

Questa è una struttura di array annidati: l'array esterno contiene le
ruote, mentre ogni elemento contiene un altro array con i cinque numeri.

### Passaggio 3 -- Scorrere le ruote con `foreach`

``` php
foreach ($ruote as $ruota) {
    // ...
}
```

Il ciclo `foreach` visita tutti gli elementi dell'array `$ruote`.

A ogni iterazione, la variabile `$ruota` assume il valore del nome della
ruota corrente:

1.  prima iterazione: `Bari`;
2.  seconda iterazione: `Cagliari`;
3.  terza iterazione: `Firenze`;
4.  e così via.

Non occorre conoscere in anticipo il numero di elementi dell'array.

### Passaggio 4 -- Generare cinque numeri con `for`

``` php
$numeri = [];

for ($i = 0; $i < 5; $i++) {
    $numeri[] = rand(1, 90);
}
```

Il ciclo `for` viene eseguito cinque volte.

La variabile `$i` assume i valori 0, 1, 2, 3 e 4.

L'istruzione:

``` php
$numeri[] = rand(1, 90);
```

aggiunge il numero appena generato in fondo all'array `$numeri`.

È una forma abbreviata di:

``` php
$numeri[count($numeri)] = rand(1, 90);
```

### Passaggio 5 -- Collegare ruota e numeri

``` php
$estrazioni[$ruota] = $numeri;
```

Questa istruzione crea nell'array `$estrazioni` un elemento la cui
chiave è il nome della ruota e il cui valore è l'array dei cinque
numeri.

Per esempio, al termine dell'elaborazione di Bari, si avrà una struttura
equivalente a:

``` php
$estrazioni["Bari"] = [12, 34, 45, 67, 89];
```

### Passaggio 6 -- Visualizzare i risultati

``` php
foreach ($estrazioni as $ruota => $numeri) {
    // stampa una riga
}
```

In questo caso `foreach` utilizza due variabili:

-   `$ruota` riceve la chiave associativa, ad esempio `Bari`;
-   `$numeri` riceve il valore associato, cioè l'array dei cinque
    numeri.

All'interno della riga, il ciclo `for` stampa gli elementi dell'array.

### Osservazioni didattiche

-   Il numero di ruote può cambiare senza dover riscrivere la tabella.
-   Il numero di estrazioni per ruota può essere modificato intervenendo
    sul limite del ciclo `for`.
-   Il codice è più compatto e riutilizzabile rispetto alla prima
    versione.
-   Non è ancora presente alcun controllo sui numeri già estratti.

------------------------------------------------------------------------

# 4. Versione 3 -- Soluzione con controllo dei numeri duplicati

## 4.1 Idea della soluzione

Questa è la versione più completa dell'esercitazione.

Per ogni ruota dobbiamo generare cinque numeri casuali compresi tra 1 e
90, assicurandoci che non siano ripetuti all'interno della stessa ruota.

La strategia è:

1.  creare l'array vuoto `$numeri`;
2.  generare un numero casuale;
3.  verificare se il numero è già presente nell'array;
4.  se non è presente, inserirlo;
5.  se è già presente, scartarlo e generarne un altro;
6.  ripetere il procedimento fino a quando l'array contiene cinque
    numeri.

Per realizzare il controllo utilizziamo:

``` php
in_array($numero, $numeri)
```

La funzione `in_array()` verifica se un valore è presente in un array:

-   restituisce `true` se il valore è presente;
-   restituisce `false` se il valore non è presente.

Utilizzeremo un ciclo `while`, perché non sappiamo in anticipo quante
estrazioni casuali saranno necessarie per ottenere cinque numeri
distinti.

## 4.2 Codice completo -- `index.php`

``` php
<?php

$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];

$estrazioni = [];

// Scorro tutte le ruote
foreach ($ruote as $ruota) {

    // Array che conterrà i cinque numeri distinti
    $numeri = [];

    // Continuo finché non ho ottenuto cinque numeri
    while (count($numeri) < 5) {

        // Genero un numero casuale tra 1 e 90
        $numero = rand(1, 90);

        // Inserisco il numero solo se non è già presente
        if (!in_array($numero, $numeri, true)) {
            $numeri[] = $numero;
        }
    }

    // Associo i numeri alla ruota corrente
    $estrazioni[$ruota] = $numeri;
}

?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulazione estrazioni Lotto - Versione 3</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f4f6f8;
        }

        h1 {
            text-align: center;
            color: #17365d;
        }

        table {
            width: 100%;
            max-width: 850px;
            margin: 25px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #b8c4ce;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #17365d;
            color: white;
        }

        td:first-child {
            font-weight: bold;
            background-color: #e8eef5;
        }

        .numero {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<h1>Simulazione estrazioni del Lotto</h1>

<table>
    <tr>
        <th>Ruota</th>
        <th>1° numero</th>
        <th>2° numero</th>
        <th>3° numero</th>
        <th>4° numero</th>
        <th>5° numero</th>
    </tr>

    <?php foreach ($estrazioni as $ruota => $numeri): ?>

        <tr>
            <td><?php echo $ruota; ?></td>

            <?php foreach ($numeri as $numero): ?>
                <td class="numero">
                    <?php echo $numero; ?>
                </td>
            <?php endforeach; ?>

        </tr>

    <?php endforeach; ?>

</table>

</body>
</html>
```

## 4.3 Spiegazione passo passo

### Passaggio 1 -- Inizializzare l'array dei numeri

``` php
$numeri = [];
```

Per ogni ruota creiamo un nuovo array vuoto.

È importante inizializzarlo all'interno del ciclo `foreach`: in questo
modo i numeri di una ruota non vengono confusi con quelli della ruota
precedente.

### Passaggio 2 -- Controllare quanti numeri sono stati inseriti

``` php
while (count($numeri) < 5) {
    // ...
}
```

`count($numeri)` restituisce il numero di elementi presenti nell'array.

Il ciclo continua finché gli elementi sono meno di cinque.

Esempio:

  Contenuto dell'array       `count()` Il ciclo continua?
  ------------------------ ----------- --------------------
  `[]`                               0 Sì
  `[12]`                             1 Sì
  `[12, 34]`                         2 Sì
  `[12, 34, 56]`                     3 Sì
  `[12, 34, 56, 78]`                 4 Sì
  `[12, 34, 56, 78, 90]`             5 No

Il ciclo `while` è adatto perché il numero di tentativi necessari non è
prevedibile.

### Passaggio 3 -- Generare un numero casuale

``` php
$numero = rand(1, 90);
```

La funzione genera un numero intero compreso tra 1 e 90.

Il risultato viene memorizzato nella variabile `$numero`.

### Passaggio 4 -- Verificare se il numero è già presente

``` php
if (!in_array($numero, $numeri, true)) {
    $numeri[] = $numero;
}
```

Analizziamo la condizione:

-   `in_array($numero, $numeri, true)` verifica se il numero è già
    presente;
-   il simbolo `!` significa NOT, cioè negazione;
-   quindi `!in_array(...)` significa: il numero **non** è presente
    nell'array.

Il terzo parametro `true` richiede un confronto stretto, evitando
conversioni automatiche di tipo.

Se il numero non è presente, viene aggiunto all'array.

Se invece è già presente, il blocco `if` non viene eseguito. Il ciclo
`while` riparte e viene generato un nuovo numero.

### Passaggio 5 -- Associare l'array alla ruota

``` php
$estrazioni[$ruota] = $numeri;
```

Quando il ciclo `while` termina, `$numeri` contiene esattamente cinque
valori distinti.

L'array viene quindi associato alla ruota corrente.

### Passaggio 6 -- Stampare i risultati

``` php
foreach ($numeri as $numero) {
    echo $numero;
}
```

In questa versione utilizziamo `foreach` anche per stampare i numeri,
perché dobbiamo semplicemente visitare tutti gli elementi dell'array.

Il codice non dipende dal valore degli indici: stampa ogni numero
presente nell'array.

------------------------------------------------------------------------

# 5. Confronto tra le tre versioni

  -----------------------------------------------------------------------
  Caratteristica    Versione 1        Versione 2        Versione 3
  ----------------- ----------------- ----------------- -----------------
  Array             Sì                Sì                Sì

  Ciclo `for`       No                Sì                No

  Ciclo `foreach`   No                Sì                Sì

  Ciclo `while`     No                No                Sì

  Funzione `rand()` Sì                Sì                Sì

  Controllo         No                No                Sì
  duplicati                                             

  Codice ripetuto   Molto             Poco              Poco

  Facilità di       Bassa             Alta              Alta
  estensione                                            

  Cinque numeri     Non garantiti     Non garantiti     Garantiti
  distinti per                                          
  ruota                                                 
  -----------------------------------------------------------------------

## Quale versione è preferibile?

La prima versione è utile per comprendere i concetti di base, ma non è
adatta a un programma che deve essere facilmente modificabile.

La seconda versione introduce i cicli e gli array annidati. È una
soluzione più ordinata e flessibile, ma non rispetta ancora la regola
dei numeri distinti sulla stessa ruota.

La terza versione è la più completa rispetto ai requisiti
dell'esercitazione: genera cinque numeri distinti per ogni ruota e
mantiene il codice compatto.

------------------------------------------------------------------------

# 6. Approfondimento: perché usare `while` nella terza versione?

Si potrebbe pensare di utilizzare un ciclo `for` con cinque iterazioni:

``` php
for ($i = 0; $i < 5; $i++) {
    $numero = rand(1, 90);

    if (!in_array($numero, $numeri, true)) {
        $numeri[] = $numero;
    }
}
```

Questa soluzione, però, presenta un problema.

Supponiamo che il programma generi questi valori:

``` text
12, 34, 12, 56, 78
```

Il terzo valore è già presente e viene scartato. Al termine delle cinque
iterazioni l'array contiene soltanto quattro numeri:

``` text
12, 34, 56, 78
```

Il ciclo `for` termina comunque, perché ha eseguito cinque iterazioni.
Non garantisce quindi che siano stati inseriti cinque numeri validi.

Con `while`, invece, il programma controlla il numero effettivo di
elementi inseriti:

``` php
while (count($numeri) < 5) {
    // genera e verifica un nuovo numero
}
```

Se un numero è duplicato, non viene aggiunto e il ciclo continua. In
questo modo il programma termina solo quando sono stati memorizzati
cinque numeri distinti.

------------------------------------------------------------------------

# 7. Verifica pratica del funzionamento

Dopo aver inserito il codice della terza versione in `index.php`:

1.  avviare Apache;
2.  aprire `http://localhost/lotto/`;
3.  verificare che siano presenti undici righe, una per ogni ruota;
4.  verificare che ogni riga contenga cinque numeri;
5.  aggiornare la pagina più volte;
6.  osservare che i numeri cambiano a ogni nuova esecuzione;
7.  controllare che, nella stessa riga, non siano presenti numeri
    duplicati.

È possibile che lo stesso numero compaia su ruote differenti: il
controllo viene effettuato separatamente per ciascuna ruota.

## Attenzione: simulazione didattica

Il programma simula la generazione di numeri casuali e non interroga i
risultati ufficiali del Lotto. Non prevede alcuna capacità di previsione
delle estrazioni.

------------------------------------------------------------------------

# 8. Esercizi di consolidamento

## Esercizio 1 -- Modificare il numero delle ruote

Aggiungere una nuova ruota all'array `$ruote`.

-   Nella versione 1 sarà necessario aggiungere manualmente anche
    l'array dei numeri e la riga HTML.
-   Nelle versioni 2 e 3 sarà sufficiente aggiungere il nome all'array
    `$ruote`.

**Domanda:** quale soluzione richiede meno modifiche? Perché?

## Esercizio 2 -- Modificare il numero di numeri estratti

Modificare il programma affinché ogni ruota estragga sei numeri anziché
cinque.

Nella versione 2, individuare il ciclo:

``` php
for ($i = 0; $i < 5; $i++)
```

Nella versione 3, individuare la condizione:

``` php
while (count($numeri) < 5)
```

Adeguare anche le intestazioni e la visualizzazione HTML.

## Esercizio 3 -- Visualizzare i numeri in ordine crescente

Dopo aver generato i cinque numeri di una ruota, utilizzare:

``` php
sort($numeri);
```

La funzione `sort()` ordina l'array in ordine crescente e ne reindicizza
gli elementi.

**Domanda:** in quale punto del programma è opportuno inserire `sort()`?

## Esercizio 4 -- Visualizzare il totale dei numeri generati

Al termine della generazione, calcolare quanti numeri sono stati
prodotti complessivamente.

Suggerimento: il numero di ruote può essere ricavato con
`count($ruote)`. Ogni ruota genera cinque numeri.

**Domanda:** quale risultato si ottiene con undici ruote e cinque numeri
per ruota?

## Esercizio 5 -- Utilizzare una variabile per il numero di estrazioni

Sostituire il valore fisso `5` con una variabile:

``` php
$quantitaNumeri = 5;
```

Utilizzare la variabile sia nel ciclo di generazione sia nella
visualizzazione della tabella.

**Obiettivo:** rendere il programma più facilmente configurabile.

------------------------------------------------------------------------

# 9. Riepilogo dei concetti PHP utilizzati

  Elemento               Funzione
  ---------------------- -----------------------------------------------
  `rand(1, 90)`          Genera un numero intero casuale tra 1 e 90
  `$array = []`          Crea un array vuoto
  `$array[] = $valore`   Aggiunge un elemento in fondo all'array
  `foreach`              Scorre gli elementi di un array
  `for`                  Ripete un blocco un numero definito di volte
  `while`                Ripete un blocco finché una condizione è vera
  `count($array)`        Restituisce il numero di elementi dell'array
  `in_array()`           Verifica se un valore è presente nell'array
  `sort()`               Ordina un array in senso crescente
  `echo`                 Stampa un valore nell'output HTML

## Conclusione

L'esercitazione mostra un percorso graduale di miglioramento del codice:

-   dalla scrittura manuale e ripetitiva;
-   all'utilizzo dei cicli per automatizzare le operazioni;
-   fino all'introduzione di un controllo logico per garantire il
    rispetto di un vincolo.

Il passaggio fondamentale è comprendere che non basta generare cinque
numeri: occorre verificare che siano stati effettivamente memorizzati
cinque valori distinti. Per questo motivo, nella terza versione, il
ciclo `while` rappresenta la scelta più adatta.
