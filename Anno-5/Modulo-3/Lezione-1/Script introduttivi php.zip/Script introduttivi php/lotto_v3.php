<?php

$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];

$estrazioni = [];

// Scorro tutte le ruote
foreach ($ruote as $ruota) {

    // Array che conterrà i cinque numeri distinti
    $numeri = [];

    // Continuo finché non ho ottenuto cinque numeri
    while (count($numeri) < 5) {

        // Genero un numero casuale tra 1 e 90
        $numero = rand(1, 90);

        // Inserisco il numero solo se non è già presente
        if (!in_array($numero, $numeri, true)) {
            $numeri[] = $numero;
        }
    }

    // Associo i numeri alla ruota corrente
    $estrazioni[$ruota] = $numeri;
}

?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulazione estrazioni Lotto - Versione 3</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f4f6f8;
        }

        h1 {
            text-align: center;
            color: #17365d;
        }

        table {
            width: 100%;
            max-width: 850px;
            margin: 25px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #b8c4ce;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #17365d;
            color: white;
        }

        td:first-child {
            font-weight: bold;
            background-color: #e8eef5;
        }

        .numero {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<h1>Simulazione estrazioni del Lotto</h1>

<table>
    <tr>
        <th>Ruota</th>
        <th>1° numero</th>
        <th>2° numero</th>
        <th>3° numero</th>
        <th>4° numero</th>
        <th>5° numero</th>
    </tr>

    <?php foreach ($estrazioni as $ruota => $numeri): ?>

        <tr>
            <td><?php echo $ruota; ?></td>

            <?php foreach ($numeri as $numero): ?>
                <td class="numero">
                    <?php echo $numero; ?>
                </td>
            <?php endforeach; ?>

        </tr>

    <?php endforeach; ?>

</table>

</body>
</html>