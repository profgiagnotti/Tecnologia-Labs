<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esempi GET e POST</title>
</head>
<body>
    <h1>Esempi GET e POST</h1>
    <a href="get.php">Esempio GET</a><br>
    <a href="post.php">Esempio POST</a><br>
</body>
</html>