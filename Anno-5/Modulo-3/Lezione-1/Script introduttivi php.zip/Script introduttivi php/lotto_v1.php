<?php
// Elenco delle ruote
$ruote = [
    "Bari",
    "Cagliari",
    "Firenze",
    "Genova",
    "Milano",
    "Napoli",
    "Palermo",
    "Roma",
    "Torino",
    "Venezia",
    "Nazionale"
];

// Generazione manuale dei cinque numeri per ogni ruota.
// Ogni chiamata a rand(1, 90) restituisce un numero tra 1 e 90.

$bari = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$cagliari = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$firenze = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$genova = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$milano = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$napoli = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$palermo = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$roma = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$torino = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$venezia = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];

$nazionale = [
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90),
    rand(1, 90)
];
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulazione estrazioni Lotto - Versione 1</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f4f6f8;
        }

        h1 {
            text-align: center;
            color: #17365d;
        }

        table {
            width: 100%;
            max-width: 850px;
            margin: 25px auto;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #b8c4ce;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #17365d;
            color: white;
        }

        td:first-child {
            font-weight: bold;
            background-color: #e8eef5;
        }

        .numero {
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<h1>Simulazione estrazioni del Lotto</h1>

<table>
    <tr>
        <th>Ruota</th>
        <th>1° numero</th>
        <th>2° numero</th>
        <th>3° numero</th>
        <th>4° numero</th>
        <th>5° numero</th>
    </tr>

    <tr>
        <td><?php echo $ruote[0]; ?></td>
        <td class="numero"><?php echo $bari[0]; ?></td>
        <td class="numero"><?php echo $bari[1]; ?></td>
        <td class="numero"><?php echo $bari[2]; ?></td>
        <td class="numero"><?php echo $bari[3]; ?></td>
        <td class="numero"><?php echo $bari[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[1]; ?></td>
        <td class="numero"><?php echo $cagliari[0]; ?></td>
        <td class="numero"><?php echo $cagliari[1]; ?></td>
        <td class="numero"><?php echo $cagliari[2]; ?></td>
        <td class="numero"><?php echo $cagliari[3]; ?></td>
        <td class="numero"><?php echo $cagliari[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[2]; ?></td>
        <td class="numero"><?php echo $firenze[0]; ?></td>
        <td class="numero"><?php echo $firenze[1]; ?></td>
        <td class="numero"><?php echo $firenze[2]; ?></td>
        <td class="numero"><?php echo $firenze[3]; ?></td>
        <td class="numero"><?php echo $firenze[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[3]; ?></td>
        <td class="numero"><?php echo $genova[0]; ?></td>
        <td class="numero"><?php echo $genova[1]; ?></td>
        <td class="numero"><?php echo $genova[2]; ?></td>
        <td class="numero"><?php echo $genova[3]; ?></td>
        <td class="numero"><?php echo $genova[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[4]; ?></td>
        <td class="numero"><?php echo $milano[0]; ?></td>
        <td class="numero"><?php echo $milano[1]; ?></td>
        <td class="numero"><?php echo $milano[2]; ?></td>
        <td class="numero"><?php echo $milano[3]; ?></td>
        <td class="numero"><?php echo $milano[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[5]; ?></td>
        <td class="numero"><?php echo $napoli[0]; ?></td>
        <td class="numero"><?php echo $napoli[1]; ?></td>
        <td class="numero"><?php echo $napoli[2]; ?></td>
        <td class="numero"><?php echo $napoli[3]; ?></td>
        <td class="numero"><?php echo $napoli[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[6]; ?></td>
        <td class="numero"><?php echo $palermo[0]; ?></td>
        <td class="numero"><?php echo $palermo[1]; ?></td>
        <td class="numero"><?php echo $palermo[2]; ?></td>
        <td class="numero"><?php echo $palermo[3]; ?></td>
        <td class="numero"><?php echo $palermo[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[7]; ?></td>
        <td class="numero"><?php echo $roma[0]; ?></td>
        <td class="numero"><?php echo $roma[1]; ?></td>
        <td class="numero"><?php echo $roma[2]; ?></td>
        <td class="numero"><?php echo $roma[3]; ?></td>
        <td class="numero"><?php echo $roma[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[8]; ?></td>
        <td class="numero"><?php echo $torino[0]; ?></td>
        <td class="numero"><?php echo $torino[1]; ?></td>
        <td class="numero"><?php echo $torino[2]; ?></td>
        <td class="numero"><?php echo $torino[3]; ?></td>
        <td class="numero"><?php echo $torino[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[9]; ?></td>
        <td class="numero"><?php echo $venezia[0]; ?></td>
        <td class="numero"><?php echo $venezia[1]; ?></td>
        <td class="numero"><?php echo $venezia[2]; ?></td>
        <td class="numero"><?php echo $venezia[3]; ?></td>
        <td class="numero"><?php echo $venezia[4]; ?></td>
    </tr>

    <tr>
        <td><?php echo $ruote[10]; ?></td>
        <td class="numero"><?php echo $nazionale[0]; ?></td>
        <td class="numero"><?php echo $nazionale[1]; ?></td>
        <td class="numero"><?php echo $nazionale[2]; ?></td>
        <td class="numero"><?php echo $nazionale[3]; ?></td>
        <td class="numero"><?php echo $nazionale[4]; ?></td>
    </tr>
</table>

</body>
</html>