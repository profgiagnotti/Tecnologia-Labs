# TPS Quinto anno script inserimento, modifica e cancellazione record PHP

Questo è un semplice repository basato su **PHP**.


## Tecnologie:
- **Apache**
- **PHP**
- **XAMPP**
- **MySQL**
- **phpMyAdmin**

## Come testare i contenuti:

1. Clona il repository:

git clone https://github.com/MarioGiagnotti/TPS-Quinto-anno-Inserimento-modifica-e-cancellazione-record-PHP.git

oppure fare il Download del file .zip


2. Visualizzazione dell'output

     - Avviare XAMPP
     - Far partire Apache
     - Far partire MySQL
     - Cliccare su Admin in corrispondenza di MySQL per avviare l'interfaccia phpMyAdmin
     - Copiare il contenuto di crea_db1.sql nella scheda SQL di phpMyAdmin ed eseguire (viene creato il database db1)
     - Copiare il contenuto della cartella di progett in C:\xampp\htdocs\php_script_interazioneDB
     - Aprire il browser e scrivere sulla barra degli indirizzi:
        **localhost\php_script_interazioneDB**
     - cliccare sui link che rappresentano le directory degli esempi
     - cliccare sui file html
     - inserire i dati nei form e premere invio
     - verificare che la tabella utenti viene modificata (controllare in phpMyAdmin aggiornando)

3. Modifica dei file

    - aprire VSC nella directory C:\xampp\htdocs\php_script_interazioneDB
    - modificare i file e testarli come descritto al punto 2