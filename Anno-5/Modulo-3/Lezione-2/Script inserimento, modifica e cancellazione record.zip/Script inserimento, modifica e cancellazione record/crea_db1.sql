-- Creazione del database
CREATE DATABASE IF NOT EXISTS db1;
USE db1;

-- Creazione della tabella utenti
CREATE TABLE IF NOT EXISTS utenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Inserimento di 10 record nella tabella utenti
INSERT INTO utenti (nome, cognome, email, username, password) VALUES
('Mario', 'Rossi', 'mario.rossi@example.com', 'mrossi', 'password1'),
('Luca', 'Bianchi', 'luca.bianchi@example.com', 'lbianchi', 'password2'),
('Giulia', 'Verdi', 'giulia.verdi@example.com', 'gverdi', 'password3'),
('Francesca', 'Neri', 'francesca.neri@example.com', 'fneri', 'password4'),
('Alessandro', 'Gialli', 'alessandro.gialli@example.com', 'agialli', 'password5'),
('Elena', 'Marrone', 'elena.marrone@example.com', 'emarrone', 'password6'),
('Paolo', 'Blu', 'paolo.blu@example.com', 'pblu', 'password7'),
('Sara', 'Rosa', 'sara.rosa@example.com', 'srosa', 'password8'),
('Davide', 'Viola', 'davide.viola@example.com', 'dviola', 'password9'),
('Martina', 'Grigio', 'martina.grigio@example.com', 'mgrigio', 'password10');
