-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Apr 02, 2025 alle 21:37
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db1`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `email`, `username`, `password`) VALUES
(1, 'Mario', 'Rossi', 'mario.rossi@example.com', 'mrossi', 'password1'),
(2, 'Luca', 'Bianchi', 'luca.bianchi@example.com', 'lbianchi', 'password2'),
(3, 'Giulia', 'Verdi', 'giulia.verdi@example.com', 'gverdi', 'password3'),
(4, 'Francesca', 'Neri', 'francesca.neri@example.com', 'fneri', 'password4'),
(5, 'Alessandro', 'Gialli', 'alessandro.gialli@example.com', 'agialli', 'password5'),
(6, 'Elena', 'Marrone', 'elena.marrone@example.com', 'emarrone', 'password6'),
(7, 'Paolo', 'Blu', 'paolo.blu@example.com', 'pblu', 'password7'),
(8, 'Sara', 'Rosa', 'sara.rosa@example.com', 'srosa', 'password8'),
(9, 'Davide', 'Viola', 'davide.viola@example.com', 'dviola', 'password9'),
(10, 'Martina', 'Grigio', 'martina.grigio@example.com', 'mgrigio', 'password10');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
