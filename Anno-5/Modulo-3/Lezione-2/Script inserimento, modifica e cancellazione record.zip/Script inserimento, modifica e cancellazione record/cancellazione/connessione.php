<?php
    //connessione con approccio orientata agli oggetti
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "db1";

    $conn = new mysqli($servername, $username, $password, $database);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    } 
?>
