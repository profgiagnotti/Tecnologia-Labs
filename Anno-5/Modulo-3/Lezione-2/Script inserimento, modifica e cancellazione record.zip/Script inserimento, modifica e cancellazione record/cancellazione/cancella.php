<?php
    // Connessione al database
    require 'connessione.php';
    
    $email = $_POST['email'];
    
    $sql = "DELETE FROM utenti WHERE email = ?";
    
    $stmt = $conn->prepare($sql);
    
    $stmt->bind_param("s", $email);
    
    if ($stmt->execute()) {
        // Controllo se il record è stato eliminato
        if ($stmt->affected_rows > 0) {
            echo "Utente eliminato con successo!";
        } else {
            echo "Nessun utente trovato con questa email.";
        }
    } else {
        echo "Errore durante l'eliminazione: " . $stmt->error;
    }
    
   
    $stmt->close();
    $conn->close();
?>