<?php
// Connessione al database
require 'connessione.php';

// Dati da inserire
$nome = $_POST['nome'];
$cognome = $_POST['cognome'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];

// QUERY PREPARATA - SICURA CONTRO SQL INJECTION
$sql = "INSERT INTO utenti (nome, cognome, email, username, password) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

// Associazione dei parametri alla query (s = stringa)
$stmt->bind_param("sssss", $nome, $cognome, $email, $username, $password);

// Esecuzione della query
if ($stmt->execute()) {
    echo "Record inserito con successo!";
} else {
    echo "Errore nell'inserimento: " . $stmt->error;
}

// Chiusura dello statement e della connessione
$stmt->close();
$conn->close();
?>
