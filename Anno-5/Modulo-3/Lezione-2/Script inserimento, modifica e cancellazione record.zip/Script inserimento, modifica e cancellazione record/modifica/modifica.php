<?php
    // Connessione al database
    require 'connessione.php';
    
    $email = $_POST['email'];
    $new_password = $_POST['password'];
    
    $sql = "UPDATE utenti SET password = ? WHERE email = ?";
    
    $stmt = $conn->prepare($sql);
    
    $stmt->bind_param("ss", $new_password, $email);
    
    if ($stmt->execute()) {
        echo "Password aggiornata con successo!";
    } else {
        echo "Errore durante l'aggiornamento: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
?>
