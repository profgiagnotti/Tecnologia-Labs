-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 01, 2025 alle 23:29
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db2`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `cittadini`
--

CREATE TABLE `cittadini` (
  `codice` int(11) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `indirizzo` varchar(100) NOT NULL,
  `citta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `cittadini`
--

INSERT INTO `cittadini` (`codice`, `cognome`, `nome`, `indirizzo`, `citta`) VALUES
(1, 'Rossi', 'Mario', 'Via Roma 10', 'Milano'),
(2, 'Bianchi', 'Luca', 'Via Verdi 15', 'Torino'),
(3, 'Verdi', 'Giulia', 'Piazza Garibaldi 3', 'Napoli'),
(4, 'Neri', 'Francesca', 'Corso Italia 22', 'Firenze'),
(5, 'Gialli', 'Alessandro', 'Via Mazzini 5', 'Bologna'),
(6, 'Marrone', 'Elena', 'Via Dante 8', 'Genova'),
(7, 'Blu', 'Paolo', 'Viale Manzoni 7', 'Palermo'),
(8, 'Rosa', 'Sara', 'Via Veneto 12', 'Venezia'),
(9, 'Viola', 'Davide', 'Piazza Duomo 1', 'Roma'),
(10, 'Grigio', 'Martina', 'Via Montenapoleone 4', 'Bari');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `cittadini`
--
ALTER TABLE `cittadini`
  ADD PRIMARY KEY (`codice`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `cittadini`
--
ALTER TABLE `cittadini`
  MODIFY `codice` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
