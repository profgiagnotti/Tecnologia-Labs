<?php
  //se è stato creato uno script connessione.php lo includo
  require 'connessione.php';
  
  $sql = "SELECT * FROM cittadini";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
          echo "ID: " . $row["codice"] . " - cognome: " . $row["cognome"] . " - Nome: " . $row["nome"] . " - Indirizzo: " . $row["indirizzo"] . " - Citta: " . $row["citta"] . "<br>";
      }
  } else {
      echo "Nessun risultato";
  }
?>