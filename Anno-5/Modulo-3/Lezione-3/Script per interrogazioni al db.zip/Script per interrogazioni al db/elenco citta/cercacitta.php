<!DOCTYPE html> 
<html> 
    <head> 
    <title>Scelta della città</title>
    </head>
    <body> 
        <form action="elencocitta.php" method="post"> 
            <p>Scegli la città nell'elenco</p> 
            <select name="citta">
                <?php 
                $host = "localhost"; 
                $username = "root"; 
                $password = ""; 
                $db_nome = "db2";// connessione al server 
                $conn   = new mysqli($host, $username, $password, $db_nome);
                if ($conn->connect_errno) {
                    echo "Impossibile connettersi al server:  " . $conn->connect_error . "\n";
                exit;
                }
                // lettura dei dati dalla tabella 
                $tab_nome = "cittadini"; 
                $sql = "SELECT DISTINCT citta FROM $tab_nome ORDER BY citta"; 
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()) {
                    echo "<option value=\"".$row['citta']."\">".$row['citta']."</option> \n";
                } 
                $result->free(); 
                $conn->close(); 
                ?> 
            </select> 
            <input type="submit" name="invio" value="Cerca" /> 
        </form>
    </body>
</html>