<!DOCTYPE html>
    <html>
        <head>  
            <title>Elenco utenti per citt&agrave;</title>
        </head>
        <body> 
            <?php    
            // valore fornito dall'utente
            $citta = $_POST["citta"];
            echo "<h2>Elenco utenti: citt&agrave; = ". $citta . "</h2> \n";
            $host = "localhost";
            $username = "root";
            $password = "";
            $db_nome = "db2";    
            // connessione al server
            $conn = new mysqli($host, $username, $password, $db_nome);
            if ($conn->connect_errno) {      
                echo "Impossibile connettersi al server:  " . $conn->connect_error . "\n";      
                exit;
            }    
            // lettura dei dati dalla tabella  
            $tab_nome = "cittadini"; 
            $sql = "SELECT * FROM $tab_nome WHERE Citta = '$citta'";
            $result = $conn->query($sql);  
            ?>
            <!-- intestazione della tabella -->  
             <table border="1">  
                <tr>  
                    <th>Codice</th>  
                    <th>Cognome</th>  
                    <th>Nome</th>  
                    <th>Indirizzo</th>  
                </tr>  
                <?php
                    while ($row = $result->fetch_assoc()) {
                              // operazioni sulla riga 
                              echo "<tr> \n";
                              echo "<td>" . $row["codice"] . "</td> \n";
                              echo "<td>" . $row["cognome"] . "</td> \n";
                              echo "<td>" . $row["nome"] . "</td> \n";
                              echo "<td>" . $row["indirizzo"] . "</td> \n";
                              echo "</tr> \n";
                              } 
                              // fine while
                              $result->free(); 
                              $conn->close();  
                ?>  
            </table>
        </body>
        </html>