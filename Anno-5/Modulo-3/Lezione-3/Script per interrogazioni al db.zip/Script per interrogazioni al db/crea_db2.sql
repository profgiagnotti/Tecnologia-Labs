CREATE DATABASE IF NOT EXISTS db2;

USE db2;

CREATE TABLE IF NOT EXISTS cittadini (
    codice INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    cognome VARCHAR(50) NOT NULL,    
    nome VARCHAR(50) NOT NULL,
    indirizzo VARCHAR(100) NOT NULL,
    citta VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS utenti (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,      
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL,  
    email VARCHAR(100) NOT NULL
);

-- Inserimento di 10 record nella tabella cittadini
INSERT INTO cittadini (cognome, nome, indirizzo, citta) VALUES
('Rossi', 'Mario', 'Via Roma 10', 'Milano'),
('Bianchi', 'Luca', 'Via Verdi 15', 'Torino'),
('Verdi', 'Giulia', 'Piazza Garibaldi 3', 'Napoli'),
('Neri', 'Francesca', 'Corso Italia 22', 'Firenze'),
('Gialli', 'Alessandro', 'Via Mazzini 5', 'Bologna'),
('Marrone', 'Elena', 'Via Dante 8', 'Genova'),
('Blu', 'Paolo', 'Viale Manzoni 7', 'Palermo'),
('Rosa', 'Sara', 'Via Veneto 12', 'Venezia'),
('Viola', 'Davide', 'Piazza Duomo 1', 'Roma'),
('Grigio', 'Martina', 'Via Montenapoleone 4', 'Bari');

-- Inserimento di 10 record nella tabella utenti
INSERT INTO utenti (nome, cognome, email) VALUES
('Mario', 'Rossi', 'mario.rossi@example.com'),
('Luca', 'Bianchi', 'luca.bianchi@example.com'),
('Giulia', 'Verdi', 'giulia.verdi@example.com'),
('Francesca', 'Neri', 'francesca.neri@example.com'),
('Alessandro', 'Gialli', 'alessandro.gialli@example.com'),
('Elena', 'Marrone', 'elena.marrone@example.com'),
('Paolo', 'Blu', 'paolo.blu@example.com'),
('Sara', 'Rosa', 'sara.rosa@example.com'),
('Davide', 'Viola', 'davide.viola@example.com'),
('Martina', 'Grigio', 'martina.grigio@example.com');
