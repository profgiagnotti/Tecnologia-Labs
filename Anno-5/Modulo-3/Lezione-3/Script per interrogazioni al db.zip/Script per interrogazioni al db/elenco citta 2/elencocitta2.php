<!DOCTYPE html> 
<?php  
$host = "localhost";  
$username = "root";  
$password = "";  
$db_nome = "db2";  
$tab_nome = "cittadini";
$conn = new mysqli($host, $username, $password, $db_nome);  
if ($conn->connect_errno) {    
    echo "Impossibile connettersi al server:  " . $conn->connect_error . "\n";    
    exit;  
}?>
<html>
    <head>  
        <title>Elenco utenti per citt&agrave;</title>
        </head>
        <body>  
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">    
                <p>Scegli la citt&agrave; nell'elenco</p>     
                <select name="citta">
                    <?php
                    // comando SQL
                    $sql = "SELECT DISTINCT Citta FROM $tab_nome ORDER BY Citta";
                    $result = $conn->query($sql);
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value=\"" . $row['Citta'] . "\">" . $row['Citta'] . "</option> \n";    
                    }    
                    ?>    
                </select>    
                <input type="submit" name="invio" value="Cerca" />    
                <input type="submit" name="aggiorna" value="Aggiorna" />  
                </form>  
                <?php    
                    if(isset($_POST["aggiorna"])) {
                        header("Location: " . $_SERVER['PHP_SELF'] );    
                    }    if(isset($_POST["invio"])) {
                        // acquisisce il dato dal form HTML
                        $citta = $_POST["citta"];
                        echo "<h2>Elenco utenti: citt&agrave; = ". $citta . "</h2> \n";
                        // comando SQL
                        $sql = "SELECT * FROM $tab_nome WHERE citta = '$citta'";
                        $result = $conn->query($sql);  
                ?>  
                <!-- intestazione della tabella -->  
                 <table border="1">  
                    <tr>  
                        <th>Codice</th>  
                        <th>Cognome</th>  
                        <th>Nome</th>  
                        <th>Indirizzo</th>  
                        </tr>  <?php
                        while ($row = $result->fetch_assoc()) {
                            // operazioni sulla riga 
                            echo "<tr> \n";
                            echo "<td>" . $row["codice"] . "</td> \n";
                            echo "<td>" . $row["cognome"] . "</td> \n";
                            echo "<td>" . $row["nome"] . "</td> \n";
                            echo "<td>" . $row["indirizzo"] . "</td> \n";
                            echo "</tr> \n";
                        } // fine while    
                        } // fine isset su invio
                        $result->free();
                        $conn->close();  
                ?>  
                </table>
            </body>
        </html>