# TPS Quinto anno script cookies e sessioni PHP

Questo è un semplice repository basato su **PHP**.


## Tecnologie:
- **Apache**
- **PHP**
- **XAMPP**

## Come testare i contenuti:

1. Clona il repository:

git clone https://github.com/MarioGiagnotti/TPS-Quinto-anno-cookies-e-sessioni-PHP.git

oppure fare il Download del file .zip


2. Visualizzazione dell'output

     - Avviare XAMPP
     - Far partire Apache
     - Copiare il contenuto della cartella di progetto in C:\xampp\htdocs\php_script_cookies_sessioni
     - Aprire il browser e scrivere sulla barra degli indirizzi:
        **localhost\php_script_cookies_sessioni**
     - cliccare sui link che rappresentano le directory degli esempi
     - cliccare sui file login.php (username:admin, password:12345) e sul file index.php
     - inserire i dati nei form e premere invio

3. Modifica dei file

    - aprire VSC nella directory C:\xampp\htdocs\php_script_cookies_sessioni
    - modificare i file e testarli come descritto al punto 2