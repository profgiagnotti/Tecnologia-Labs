<?php
session_start();

// Modifica il valore della variabile di sessione 'utente'
$_SESSION['utente'] = "Nuovo Utente";

// Reindirizza alla pagina principale
header("Location: index.php");
exit();
?>
