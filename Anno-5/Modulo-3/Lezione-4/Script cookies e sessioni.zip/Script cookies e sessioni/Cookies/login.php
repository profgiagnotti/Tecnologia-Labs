<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Simuliamo un login corretto (username: admin, password: 12345)
    if ($username === "admin" && $password === "12345") {
        $_SESSION["username"] = $username;

        // Se l'utente ha selezionato "Ricordami", creiamo un cookie
        if (isset($_POST["remember"])) {
            setcookie("username", $username, time() + (86400 * 30), "/"); // Cookie valido per 30 giorni
        }

        header("Location: dashboard.php");
        exit();
    } else {
        echo "Credenziali errate.";
    }
}
?>

<form method="post">
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    <input type="checkbox" name="remember"> Ricordami<br>
    <input type="submit" value="Login">
</form>
