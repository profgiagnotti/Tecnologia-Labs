<?php
session_start();

// Se la sessione non è attiva, proviamo a recuperare il valore dal cookie
if (!isset($_SESSION["username"]) && isset($_COOKIE["username"])) {
    $_SESSION["username"] = $_COOKIE["username"];
}

// Se l'utente non è autenticato, lo rimandiamo al login
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}

echo "Benvenuto, " . $_SESSION["username"];
?>

<a href="logout.php">Logout</a>