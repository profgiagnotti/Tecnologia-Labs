<?php

//richiamiamo gli script che contengono le classi carrello_new e MioCarrello
require_once("Carrello.php");
require_once("MioCarrello.php");

$carrello = new MioCarrello();
$carrello->aggiungiArticolo("Mela");
$carrello->aggiungiArticolo("Pane");

// Impostiamo il prezzo per gli articoli
$carrello->setPrezzo(2.5);

// Mostriamo gli articoli con il prezzo
$carrello->mostraArticoliConPrezzo();

?>