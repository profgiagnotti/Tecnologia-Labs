<?php
class Carrello {
    protected $articoli = [];

    // Costruttore con la sintassi nuova
    public function __construct() {
        $this->articoli = [];
        echo "Carrello creato!";
    }

    public function aggiungiArticolo($articolo) {
        $this->articoli[] = $articolo;
    }

    public function mostraArticoli() {
        foreach ($this->articoli as $articolo) {
            echo $articolo . "<br>";
        }
    }
}

?>