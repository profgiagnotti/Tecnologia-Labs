<?php

class MioCarrello extends Carrello {
    private $prezzo;

    // Metodo per impostare il prezzo
    public function setPrezzo($prezzo) {
        $this->prezzo = $prezzo;
    }

    // Metodo per ottenere il prezzo
    public function getPrezzo() {
        return $this->prezzo;
    }

    // Metodo per mostrare articoli e prezzo
    public function mostraArticoliConPrezzo() {
        foreach ($this->articoli as $articolo) {
            echo $articolo . " - Prezzo: " . $this->prezzo . "<br>";
        }
    }
}
?>