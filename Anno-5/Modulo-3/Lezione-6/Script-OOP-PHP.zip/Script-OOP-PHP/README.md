# TPS Quinto anno script OOP PHP

Questo è un semplice repository basato su **PHP**.


## Tecnologie:
- **Apache**
- **PHP**
- **XAMPP**

## Come testare i contenuti:

1. Clona il repository:

git clone https://github.com/MarioGiagnotti/TPS-Quinto-anno-OOP-PHP.git

oppure fare il Download del file .zip


2. Visualizzazione dell'output

     - Avviare XAMPP
     - Far partire Apache
     - Copiare il contenuto della cartella di progetto in C:\xampp\htdocs\php_script_OOP
     - Aprire il browser e scrivere sulla barra degli indirizzi:
        **localhost\php_script_OOP**
     - cliccare sui link che rappresentano le directory degli esempi
     - cliccare sui file .php (per la cartella Ereditarietà cliccare su provaCarrello.php)

3. Modifica dei file

    - aprire VSC nella directory C:\xampp\htdocs\php_script_OOP
    - modificare i file e testarli come descritto al punto 2