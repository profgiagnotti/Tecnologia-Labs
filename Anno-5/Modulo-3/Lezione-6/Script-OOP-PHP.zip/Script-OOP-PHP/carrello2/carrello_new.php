<?php
class Carrello {
    private $articoli = [];

    // Costruttore con la sintassi nuova
    public function __construct() {
        $this->articoli = [];
        echo "Carrello creato!";
    }

    public function aggiungiArticolo($articolo) {
        $this->articoli[] = $articolo;
    }

    public function mostraArticoli() {
        foreach ($this->articoli as $articolo) {
            echo $articolo . "<br>";
        }
    }
}

// Creazione di un oggetto Carrello
$carrello = new Carrello();  // Chiamata al costruttore __construct
$carrello->aggiungiArticolo("Mela");
$carrello->aggiungiArticolo("Pane");
$carrello->mostraArticoli();
?>