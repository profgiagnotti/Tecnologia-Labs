<?php
session_start();

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Landing Page</title>
    <link rel="stylesheet" href="stile.css">
</head>
<body>
    <div class="welcome-container">
        <h1>Benvenuto, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h1>
        <a href="logout.php" class="btn">LOGOUT</a>
    </div>
    
</body>
</html>

