CREATE DATABASE IF NOT EXISTS area_riservata;

USE area_riservata;

CREATE TABLE utenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    ruolo ENUM('admin', 'user') NOT NULL DEFAULT 'user'
);