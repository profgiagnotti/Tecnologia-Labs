# TPS Quinto anno script Accesso area riservata PHP

Questo è un semplice repository basato su **PHP**.


## Tecnologie:
- **Apache**
- **PHP**
- **XAMPP**
- **MySQL**
- **phpMyAdmin**

## Come testare i contenuti:

1. Clona il repository:

git clone https://github.com/MarioGiagnotti/TPS-Quinto-anno-accesso-area-riservata-PHP.git

oppure fare il Download del file .zip


2. Visualizzazione dell'output

     - Avviare XAMPP
     - Far partire Apache
     - Far partire MySQL
     - Copiare il contenuto della cartella di progetto in C:\xampp\htdocs\php_script_areariservata
     - Aprire il browser e scrivere sulla barra degli indirizzi:
        **localhost\php_script_areariservata**
     - cliccare sui login.php (utente sempice:mario,12345   admin:mario2,12345)
     - eventualmente registrarsi e modificare il ruolo in phpMyAdmin

3. Modifica dei file

    - aprire VSC nella directory C:\xampp\htdocs\php_script_areariservata
    - modificare i file e testarli come descritto al punto 2